public class Personale {
    protected String codice;
    protected String cognome;
    protected String nome;
    protected int annoAssunzione;

    public Personale(String codice, String cognome, String nome, int annoAssunzione) {
        this.codice = codice;
        this.cognome = cognome;
        this.nome = nome;
        this.annoAssunzione = annoAssunzione;
    }

    public int calcolaAnniServizio() {
        return java.time.Year.now().getValue() - annoAssunzione;
    }

    public double getCostoOrario() {
        return 0.0;
    }
}