class Funzionario extends Personale {
    public Funzionario(String codice, String cognome, String nome, int annoAssunzione) {
        super(codice, cognome, nome, annoAssunzione);
    }

    @Override
    public double getCostoOrario() {
        return calcolaAnniServizio() < 10 ? 70.0 : 80.0;
    }
}