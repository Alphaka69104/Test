class Progetto {
    private Personale[] membri;
    private int[] ore;
    private int count;

    public Progetto(int maxMembri) {
        membri = new Personale[maxMembri];
        ore = new int[maxMembri];
        count = 0;
    }

    public void aggiungiMembro(Personale p, int oreLavoro) {
        if (count < membri.length) {
            membri[count] = p;
            ore[count] = oreLavoro;
            count++;
        } else {
            System.out.println("Impossibile aggiungere altri membri al progetto.");
        }
    }

    public double calcolaCostoTotale() {
        double costoTotale = 0.0;
        for (int i = 0; i < count; i++) {
            costoTotale += membri[i].getCostoOrario() * ore[i];
        }
        return costoTotale;
    }
}