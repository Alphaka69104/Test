class Tecnico extends Personale {
    private String areaCompetenza;
    private boolean interno;

    public Tecnico(String codice, String cognome, String nome, int annoAssunzione, String areaCompetenza, boolean interno) {
        super(codice, cognome, nome, annoAssunzione);
        this.areaCompetenza = areaCompetenza;
        this.interno = interno;
    }

    @Override
    public double getCostoOrario() {
        double costoBase = areaCompetenza.equalsIgnoreCase("informatica-telecomunicazioni") ? 40.0 : 50.0;
        if (interno) {
            costoBase += calcolaAnniServizio();
        }
        return costoBase;
    }
}