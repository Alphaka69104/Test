public class Main {
    public static void main(String[] args) {
        Progetto progetto = new Progetto(5);

        Dirigente dirigente = new Dirigente("D001", "Rossi", "Mario", 2010);
        Funzionario funzionarioJunior = new Funzionario("F001", "Verdi", "Luigi", 2018);
        Funzionario funzionarioSenior = new Funzionario("F002", "Rosi", "Peach", 2005);
        Tecnico tecnicoInterno = new Tecnico("T001", "Gialli", "Daisy", 2015, "informatica-telecomunicazioni", true);
        Tecnico tecnicoEsterno = new Tecnico("T002", "Marroni", "DK", 2020, "elettronica-automazione", false);

        progetto.aggiungiMembro(dirigente, 50);
        progetto.aggiungiMembro(funzionarioJunior, 30);
        progetto.aggiungiMembro(funzionarioSenior, 40);
        progetto.aggiungiMembro(tecnicoInterno, 60);
        progetto.aggiungiMembro(tecnicoEsterno, 70);

        System.out.println("Costo totale del progetto: " + progetto.calcolaCostoTotale() + " €");
    }
}
